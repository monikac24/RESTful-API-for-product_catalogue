package com.productcatalogue.product_catalog.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;
import java.util.Map;

@Document(collection = "products")  // Specifies the MongoDB collection name
public class Product {

    @Id
    private String id;  // Unique identifier for the product

    private String name;  // Name of the product
    private String description;  // Description of the product
    private double price;  // Price of the product

    private List<String> categories;  // Categories the product belongs to

    private List<Map<String, String>> attributes;  // Additional attributes as key-value pairs (e.g., size, color)

    private Availability availability;  // Availability object containing inStock and quantity

    private List<Rating> ratings;  // List of user ratings

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public List<String> getCategories() {
        return categories;
    }

    public void setCategories(List<String> categories) {
        this.categories = categories;
    }

    public List<Map<String, String>> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<Map<String, String>> attributes) {
        this.attributes = attributes;
    }

    public Availability getAvailability() {
        return availability;
    }

    public void setAvailability(Availability availability) {
        this.availability = availability;
    }

    public List<Rating> getRatings() {
        return ratings;
    }

    public void setRatings(List<Rating> ratings) {
        this.ratings = ratings;
    }

    // Inner class for Availability
    public static class Availability {
        private boolean inStock;  // Indicates if the product is in stock
        private int quantity;  // Available quantity of the product

        // Getters and Setters
        public boolean isInStock() {
            return inStock;
        }

        public void setInStock(boolean inStock) {
            this.inStock = inStock;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }
    }

    // Inner class for Rating
    public static class Rating {
        private String userId;  // Unique identifier for the user
        private int rating;  // Rating value (e.g., 1 to 5)
        private String comment;  // Optional comment by the user

        // Getters and Setters
        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public int getRating() {
            return rating;
        }

        public void setRating(int rating) {
            this.rating = rating;
        }

        public String getComment() {
            return comment;
        }

        public void setComment(String comment) {
            this.comment = comment;
        }
    }
}
