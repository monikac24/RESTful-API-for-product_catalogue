package com.productcatalogue.product_catalog.controller;

import com.productcatalogue.product_catalog.model.Product;
import com.productcatalogue.product_catalog.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    // Get all products
    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = productService.getAllProducts();
        return ResponseEntity.ok(products);  // Return 200 OK with list of products
    }

    // Get product by ID
    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable String id) {
        Product product = productService.getProductById(id);
        if (product == null) {
            return ResponseEntity.notFound().build();  // Return 404 Not Found if product doesn't exist
        }
        return ResponseEntity.ok(product);  // Return 200 OK with product
    }

    // Add a new product
    @PostMapping
    public ResponseEntity<Product> addProduct(@RequestBody Product product) {
        if (product == null || product.getName() == null || product.getPrice() <= 0) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);  // Return 400 Bad Request for invalid data
        }

        Product savedProduct = productService.addProduct(product);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedProduct);  // Return 201 Created with saved product
    }

    // Update product by ID
    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable String id, @RequestBody Product product) {
        // Ensure the new product ID is set correctly
        product.setId(id); // Keep the old ID as per the request path

        // Update the product
        Product updatedProduct = productService.updateProduct(id, product);

        // Check if the product exists
        if (updatedProduct == null) {
            return ResponseEntity.notFound().build();  // Return 404 Not Found if not found
        }

        // Return the updated product with status 200 OK
        return ResponseEntity.ok(updatedProduct);
    }



    // Delete product by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable String id) {
        Product product = productService.getProductById(id);
        if (product == null) {
            return ResponseEntity.notFound().build();  // Return 404 Not Found if product doesn't exist
        }

        productService.deleteProduct(id);
        return ResponseEntity.noContent().build();  // Return 204 No Content on successful deletion
    }
}
